package db.entity;

import domain.PriceDomain;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

public class HotelEntity {
    private int id;
    private String name;
    private String location;
    private String description;
    private PriceDomain price;
    private double totalRating;
    private Set<ReviewEntity> reviews;

    // Constructors
    public HotelEntity() {
        this.totalRating = 0;
        this.reviews = new TreeSet<>(Comparator.comparingInt(ReviewEntity::getRating).reversed());
    }

    public HotelEntity(int id, String name, String location, String description, PriceDomain price) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.description = description;
        this.price = price;
        this.totalRating = 0;
        this.reviews = new TreeSet<>(Comparator.comparingInt(ReviewEntity::getRating).reversed());

    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public PriceDomain getPrice() {
        return price;
    }

    public void setPrice(PriceDomain price) {
        this.price = price;
    }

    public double getTotalRating() {
        return totalRating;
    }

    public void setTotalRating(double totalRating) {
        this.totalRating = totalRating;
    }

    public Set<ReviewEntity> getReviews() {
        return reviews;
    }
}
