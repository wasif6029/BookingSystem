package db.entity;

public class ReviewEntity {
    private int reviewerId;
    private int rating;
    private String comment;

    // Constructors
    public ReviewEntity() {
    }

    public ReviewEntity(int reviewerId, int rating, String comment) {
        this.reviewerId = reviewerId;
        this.rating = rating;
        this.comment = comment;
    }

    // Getters and Setters
    public int getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(int reviewerId) {
        this.reviewerId = reviewerId;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
