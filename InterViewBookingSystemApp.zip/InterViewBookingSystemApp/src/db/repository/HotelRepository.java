package db.repository;

import db.entity.HotelEntity;
import db.entity.ReviewEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class HotelRepository {
    private Map<Integer, HotelEntity> hotels;

    public HotelRepository() {
        this.hotels = new HashMap<>();
    }

    public void addHotel(HotelEntity hotel) {
        hotels.put(hotel.getId(), hotel);
    }

    public HotelEntity getHotelByID(int id) {
        return hotels.get(id);
    }

    public List<HotelEntity> getAllHotels() {
        return new ArrayList<>(hotels.values());
    }

    public void putReview(int hotelID, ReviewEntity review) {
        HotelEntity hotel = hotels.get(hotelID);
        if (hotel != null) {
            hotel.getReviews().add(review);
            double totalRating = hotel.getReviews().stream().mapToInt(ReviewEntity::getRating).average().orElse(0);
            hotel.setTotalRating(totalRating);
        }
    }

    public List<HotelEntity> searchHotels(String keyword) {
        return hotels.values().stream()
                .filter(hotel ->
                        hotel.getName().toLowerCase().contains(keyword.toLowerCase()) ||
                                hotel.getDescription().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<HotelEntity> filterHotels(String location, double minPrice, double maxPrice, int minRating) {
        return hotels.values().stream()
                .filter(hotel ->
                        (location == null || hotel.getLocation().equalsIgnoreCase(location)) &&
                                hotel.getPrice().getAccommodationPrice() >= minPrice &&
                                hotel.getPrice().getAccommodationPrice() <= maxPrice &&
                                hotel.getTotalRating() >= minRating)
                .collect(Collectors.toList());
    }
}
