package service;

import db.entity.HotelEntity;
import db.entity.ReviewEntity;
import db.repository.HotelRepository;

import java.util.List;
import java.util.Set;

public class HotelService {
    private HotelRepository hotelRepository;

    public HotelService(HotelRepository hotelRepository) {
        this.hotelRepository = hotelRepository;
    }

    public HotelEntity getHotelByID(int id) {
        return hotelRepository.getHotelByID(id);
    }

    public List<HotelEntity> getAllHotels() {
        return hotelRepository.getAllHotels();
    }

    public void putReview(int hotelID, ReviewEntity review) {
        hotelRepository.putReview(hotelID, review);
    }

    public Set<ReviewEntity> getHotelReviews(int hotelID) {
        HotelEntity hotel = hotelRepository.getHotelByID(hotelID);
        return hotel != null ? hotel.getReviews() : null;
    }

    public List<HotelEntity> searchHotels(String keyword) {
        return hotelRepository.searchHotels(keyword);
    }

    public List<HotelEntity> filterHotels(String location, double minPrice, double maxPrice, int minRating) {
        return hotelRepository.filterHotels(location, minPrice, maxPrice, minRating);
    }
}