import db.entity.HotelEntity;
import db.entity.ReviewEntity;
import db.repository.HotelRepository;
import domain.PriceDomain;
import service.HotelService;

import java.util.List;

public class BookingSystemApp {
    public static void main(String[] args) {
        HotelEntity hotel1 = new HotelEntity(1, "Hotel A", "City A", "Description Cozy", new PriceDomain(100.0, 20.0, 10.0));
        HotelEntity hotel2 = new HotelEntity(2, "Hotel B", "City B", "Description Winter", new PriceDomain(120.0, 25.0, 12.0));
        HotelEntity hotel3 = new HotelEntity(3, "Hotel C", "City C", "Description Summer", new PriceDomain(150.0, 30.0, 15.0));

        System.out.println("Hotel 1: " + hotel1.getName() + ", Location: " + hotel1.getLocation());
        System.out.println("Hotel 2: " + hotel2.getName() + ", Location: " + hotel2.getLocation());
        System.out.println("Hotel 3: " + hotel3.getName() + ", Location: " + hotel3.getLocation());

        HotelRepository hotelRepository = new HotelRepository();
        HotelService hotelService = new HotelService(hotelRepository);

        hotelRepository.addHotel(hotel1);
        hotelRepository.addHotel(hotel2);
        hotelRepository.addHotel(hotel3);

        HotelEntity retrievedHotel = hotelService.getHotelByID(2);
        System.out.println("Retrieved Hotel by ID 2: " + retrievedHotel.getName());

        System.out.println("All Hotels:");
        for (HotelEntity hotel : hotelService.getAllHotels()) {
            System.out.println(" - " + hotel.getName());
        }

        ReviewEntity review1 = new ReviewEntity(101, 4, "Great experience!");
        hotelService.putReview(1, review1);

        for (ReviewEntity review : hotelService.getHotelReviews(1)) {
            System.out.println(" - Rating: " + review.getRating() + ", Comment: " + review.getComment());
        }

        List<HotelEntity> searchResults = hotelService.searchHotels("Cozy");
        for (HotelEntity hotel : searchResults) {
            System.out.println(" - " + hotel.getName() + ", Location: " + hotel.getLocation());
        }

        List<HotelEntity> filteredResults = hotelService.filterHotels("City B", 100.0, 200.0, 4);
        for (HotelEntity hotel : filteredResults) {
            System.out.println(" - " + hotel.getName() + ", Location: " + hotel.getLocation() +
                    ", Rating: " + hotel.getTotalRating() + ", Price: $" + hotel.getPrice().getAccommodationPrice());
        }
    }

}