package domain;

public class PriceDomain {
    private double accommodationPrice;
    private double foodPrice;
    private double serviceCharge;

    // Constructors
    public PriceDomain() {
    }

    public PriceDomain(double accommodationPrice, double foodPrice, double serviceCharge) {
        this.accommodationPrice = accommodationPrice;
        this.foodPrice = foodPrice;
        this.serviceCharge = serviceCharge;
    }

    // Getters and Setters
    public double getAccommodationPrice() {
        return accommodationPrice;
    }

    public void setAccommodationPrice(double accommodationPrice) {
        this.accommodationPrice = accommodationPrice;
    }

    public double getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(double foodPrice) {
        this.foodPrice = foodPrice;
    }

    public double getServiceCharge() {
        return serviceCharge;
    }

    public void setServiceCharge(double serviceCharge) {
        this.serviceCharge = serviceCharge;
    }
}
